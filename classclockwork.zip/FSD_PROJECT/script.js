(() => {
  "use strict";

  const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const PERIODS = ["08:30", "09:30", "10:30", "11:30", "13:00", "14:00"];
  const STORAGE_KEY = "classclockwork-v1";
  const COLORS = ["#6e60d8", "#3c9b82", "#d18b68", "#4c85c7", "#c65f83", "#aa7c35"];

  const demoData = {
    faculty: [
      { id: "fac-1", name: "Dr. Sharma", maxHours: 12, unavailable: ["0-0"] },
      { id: "fac-2", name: "Prof. Mehta", maxHours: 12, unavailable: ["1-5"] },
      { id: "fac-3", name: "Dr. Iyer", maxHours: 10, unavailable: ["2-0"] },
      { id: "fac-4", name: "Prof. Rao", maxHours: 12, unavailable: ["3-5"] },
      { id: "fac-5", name: "Dr. Khan", maxHours: 12, unavailable: ["0-5"] },
      { id: "fac-6", name: "Prof. Das", maxHours: 10, unavailable: ["4-0"] },
      { id: "fac-7", name: "Dr. Sen", maxHours: 12, unavailable: ["1-0"] },
      { id: "fac-8", name: "Prof. Nair", maxHours: 10, unavailable: ["2-5"] },
      { id: "fac-9", name: "Dr. Patel", maxHours: 12, unavailable: ["3-0"] },
      { id: "fac-10", name: "Prof. Bose", maxHours: 10, unavailable: ["4-5"] }
    ],
    rooms: [
      { id: "room-101", name: "Room 101", capacity: 60, equipment: [] },
      { id: "room-102", name: "Room 102", capacity: 45, equipment: [] },
      { id: "room-103", name: "Room 103", capacity: 35, equipment: [] },
      { id: "room-201", name: "Lab 201", capacity: 30, equipment: ["computers", "networking"] },
      { id: "room-202", name: "Lab 202", capacity: 28, equipment: ["computers", "electronics"] },
      { id: "room-203", name: "Lab 203", capacity: 24, equipment: ["computers"] }
    ],
    subjects: [
      { id: "sub-1", name: "Data Structures", batch: "CS-A", facultyId: "fac-1", sessions: 2, duration: 1, type: "lecture", minCapacity: 30, equipment: [] },
      { id: "sub-2", name: "Discrete Mathematics", batch: "CS-A", facultyId: "fac-2", sessions: 2, duration: 1, type: "lecture", minCapacity: 30, equipment: [] },
      { id: "sub-3", name: "Operating Systems Lab", batch: "CS-A", facultyId: "fac-3", sessions: 1, duration: 3, type: "lab", minCapacity: 28, equipment: ["computers"] },
      { id: "sub-4", name: "Database Systems", batch: "CS-B", facultyId: "fac-4", sessions: 2, duration: 1, type: "lecture", minCapacity: 35, equipment: [] },
      { id: "sub-5", name: "Algorithms", batch: "CS-B", facultyId: "fac-5", sessions: 2, duration: 1, type: "lecture", minCapacity: 35, equipment: [] },
      { id: "sub-6", name: "Computer Networks Lab", batch: "CS-B", facultyId: "fac-7", sessions: 1, duration: 2, type: "lab", minCapacity: 26, equipment: ["computers", "networking"] },
      { id: "sub-7", name: "Artificial Intelligence", batch: "CS-C", facultyId: "fac-9", sessions: 2, duration: 1, type: "lecture", minCapacity: 25, equipment: [] },
      { id: "sub-8", name: "Web Technologies", batch: "CS-C", facultyId: "fac-10", sessions: 2, duration: 1, type: "lecture", minCapacity: 25, equipment: [] }
    ],
    schedule: []
  };

  let state = loadState();
  let activeView = "batch";
  let activeResourceTab = "subjects";
  let toastTimer;
  let draggedClassId = null;
  let draggedOffset = 0;
  let lastViolations = [];
  let lastUnscheduled = [];

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
  const byId = (list, id) => list.find((item) => item.id === id);

  function loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return structuredClone(demoData);
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed.faculty) || !Array.isArray(parsed.rooms) ||
          !Array.isArray(parsed.subjects) || !Array.isArray(parsed.schedule)) {
        throw new Error("Saved timetable data is incomplete.");
      }
      return parsed;
    } catch (error) {
      console.error("Could not load the saved timetable:", error);
      return structuredClone(demoData);
    }
  }

  function persistState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      $("#save-status").textContent = "All changes saved";
    } catch (error) {
      $("#save-status").textContent = "Could not save changes";
      console.error("Could not save the timetable:", error);
      showToast("Changes are visible, but could not be saved in this browser.");
    }
  }

  function createId(prefix) {
    return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  }

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
  }

  function getTasks() {
    return state.subjects.flatMap((subject) =>
      Array.from({ length: Math.max(0, Number(subject.sessions) || 0) }, (_, index) => ({
        id: `${subject.id}-session-${index + 1}`,
        subjectId: subject.id,
        sessionIndex: index + 1,
        day: null,
        period: null,
        roomId: null
      }))
    );
  }

  function getAssignment(taskId) {
    return state.schedule.find((assignment) => assignment.id === taskId);
  }

  function hoursFor(subject) {
    return Math.max(1, Number(subject.duration) || 1);
  }

  function slotsOverlap(a, b) {
    if (a.day !== b.day) return false;
    const aSubject = byId(state.subjects, a.subjectId);
    const bSubject = byId(state.subjects, b.subjectId);
    if (!aSubject || !bSubject) return false;
    const aStart = Number(a.period);
    const bStart = Number(b.period);
    return aStart < bStart + hoursFor(bSubject) && bStart < aStart + hoursFor(aSubject);
  }

  function makeCandidateViolations(candidate, subject, assignments, includeWorkload = true) {
    const errors = [];
    const faculty = byId(state.faculty, subject.facultyId);
    const room = byId(state.rooms, candidate.roomId);
    const start = Number(candidate.period);
    const duration = hoursFor(subject);

    if (!faculty) errors.push({ type: "faculty", message: `${subject.name}: assigned faculty member is missing.` });
    if (!room) errors.push({ type: "room", message: `${subject.name}: assigned room is missing.` });
    if (!Number.isInteger(start) || start < 0 || start + duration > PERIODS.length ||
        !Number.isInteger(Number(candidate.day)) || candidate.day < 0 || candidate.day >= DAYS.length) {
      errors.push({ type: "time", message: `${subject.name}: class falls outside the weekly timetable.` });
      return errors;
    }
    if (room && room.capacity < Number(subject.minCapacity || 0)) {
      errors.push({ type: "capacity", message: `${room.name} seats ${room.capacity}; ${subject.name} needs ${subject.minCapacity}.` });
    }
    const roomEquipment = room ? (room.equipment || []) : [];
    const missingEquipment = (subject.equipment || []).filter((item) => !roomEquipment.includes(item));
    if (missingEquipment.length && room) {
      errors.push({ type: "equipment", message: `${room.name} is missing ${missingEquipment.join(", ")} for ${subject.name}.` });
    }

    if (faculty) {
      for (let period = start; period < start + duration; period += 1) {
        if ((faculty.unavailable || []).includes(`${candidate.day}-${period}`)) {
          errors.push({
            type: "availability",
            message: `${faculty.name} is unavailable on ${DAYS[candidate.day]} at ${PERIODS[period]}.`
          });
        }
      }
    }

    for (const other of assignments) {
      if (other.id === candidate.id || !slotsOverlap(candidate, other)) continue;
      const otherSubject = byId(state.subjects, other.subjectId);
      if (!otherSubject) continue;
      if (otherSubject.batch === subject.batch) {
        errors.push({ type: "batch", message: `${subject.batch} has overlapping classes: ${subject.name} and ${otherSubject.name}.` });
      }
      if (otherSubject.facultyId === subject.facultyId) {
        errors.push({
          type: "faculty",
          message: `${faculty ? faculty.name : "Faculty"} is double-booked for ${subject.name} and ${otherSubject.name} on ${DAYS[candidate.day]}.`
        });
      }
      if (other.roomId === candidate.roomId) {
        errors.push({
          type: "room",
          message: `${room ? room.name : "Room"} is double-booked for ${subject.name} and ${otherSubject.name} on ${DAYS[candidate.day]}.`
        });
      }
    }

    if (faculty && includeWorkload) {
      const used = assignments.reduce((total, item) => {
        if (item.id === candidate.id) return total;
        const assignedSubject = byId(state.subjects, item.subjectId);
        return assignedSubject && assignedSubject.facultyId === faculty.id ? total + hoursFor(assignedSubject) : total;
      }, 0);
      if (used + duration > Number(faculty.maxHours || 0)) {
        errors.push({ type: "workload", message: `${faculty.name} would exceed the ${faculty.maxHours}-hour weekly workload limit.` });
      }
    }
    return errors;
  }

  function auditSchedule() {
    const violations = [];
    const addUnique = (entry) => {
      if (!violations.some((item) => item.type === entry.type && item.message === entry.message)) violations.push(entry);
    };
    for (const assignment of state.schedule) {
      const subject = byId(state.subjects, assignment.subjectId);
      if (!subject) {
        addUnique({ type: "subject", message: "A scheduled class refers to a subject that no longer exists." });
        continue;
      }
      makeCandidateViolations(assignment, subject, state.schedule).forEach(addUnique);
    }
    return violations;
  }

  function availableRooms(subject) {
    return state.rooms.filter((room) =>
      Number(room.capacity) >= Number(subject.minCapacity || 0) &&
      (subject.equipment || []).every((item) => (room.equipment || []).includes(item))
    );
  }

  function getDomains(task, assignments) {
    const subject = byId(state.subjects, task.subjectId);
    if (!subject) return [];
    const duration = hoursFor(subject);
    const rooms = availableRooms(subject);
    const options = [];
    for (let day = 0; day < DAYS.length; day += 1) {
      for (let period = 0; period + duration <= PERIODS.length; period += 1) {
        for (const room of rooms) {
          const candidate = { ...task, day, period, roomId: room.id };
          if (makeCandidateViolations(candidate, subject, assignments).length === 0) {
            const sameBatchDay = assignments.filter((item) => {
              const otherSubject = byId(state.subjects, item.subjectId);
              return item.day === day && otherSubject && otherSubject.batch === subject.batch;
            }).length;
            const loadForDay = assignments
              .filter((item) => item.day === day && byId(state.subjects, item.subjectId)?.facultyId === subject.facultyId)
              .reduce((sum, item) => sum + hoursFor(byId(state.subjects, item.subjectId)), 0);
            options.push({ ...candidate, score: sameBatchDay * 3 + loadForDay });
          }
        }
      }
    }
    options.sort((a, b) => a.score - b.score || a.day - b.day || a.period - b.period || a.roomId.localeCompare(b.roomId));
    return options;
  }

  function solveTimetable() {
    const tasks = getTasks();
    const startedAt = performance.now();
    let visited = 0;
    let timedOut = false;
    const nodeLimit = 20000;
    const timeLimit = 1100;

    if (tasks.length === 0) return { solved: true, schedule: [], visited: 0 };
    for (const subject of state.subjects) {
      if (!byId(state.faculty, subject.facultyId)) {
        return { solved: false, reason: `${subject.name} needs an assigned faculty member before it can be scheduled.` };
      }
      if (availableRooms(subject).length === 0) {
        return { solved: false, reason: `No room has enough capacity and equipment for ${subject.name}.` };
      }
    }

    function search(remaining, assignments) {
      if (remaining.length === 0) return assignments;
      if (visited >= nodeLimit || performance.now() - startedAt > timeLimit) {
        timedOut = true;
        return null;
      }
      visited += 1;
      let chosenIndex = -1;
      let chosenOptions = null;
      for (let index = 0; index < remaining.length; index += 1) {
        const options = getDomains(remaining[index], assignments);
        if (options.length === 0) return null;
        if (chosenOptions === null || options.length < chosenOptions.length) {
          chosenOptions = options;
          chosenIndex = index;
          if (options.length === 1) break;
        }
      }
      const next = remaining[chosenIndex];
      const rest = remaining.filter((_, index) => index !== chosenIndex);
      for (const option of chosenOptions || []) {
        const result = search(rest, [...assignments, {
          id: next.id,
          subjectId: next.subjectId,
          sessionIndex: next.sessionIndex,
          day: option.day,
          period: option.period,
          roomId: option.roomId
        }]);
        if (result) return result;
        if (timedOut) return null;
      }
      return null;
    }

    const result = search(tasks, []);
    return result
      ? { solved: true, schedule: result, visited }
      : { solved: false, visited, timedOut, reason: timedOut
        ? "This schedule is highly constrained. Check availability, workload limits, and room requirements, then try again."
        : "No conflict-free timetable could be found. Add or free up resources, then try again." };
  }

  function renderSelectors() {
    const filter = $("#schedule-filter");
    const label = $("#filter-label");
    const selected = filter.value;
    const values = activeView === "batch"
      ? [...new Set(state.subjects.map((subject) => subject.batch))].sort()
      : state.faculty.map((faculty) => faculty.id);
    label.textContent = activeView === "batch" ? "Select batch" : "Select faculty";
    filter.innerHTML = values.length
      ? values.map((value) => {
        const title = activeView === "batch" ? value : (byId(state.faculty, value)?.name || "Faculty");
        return `<option value="${escapeHtml(value)}">${escapeHtml(title)}</option>`;
      }).join("")
      : `<option value="">No ${activeView === "batch" ? "batches" : "faculty"} yet</option>`;
    if (values.includes(selected)) filter.value = selected;
    $("#view-description").textContent = activeView === "batch"
      ? `Showing the ${filter.value || "selected"} batch schedule`
      : `Showing ${byId(state.faculty, filter.value)?.name || "the selected faculty"}'s teaching schedule`;
  }

  function renderTimetable() {
    renderSelectors();
    const selected = $("#schedule-filter").value;
    const filtered = state.schedule.filter((assignment) => {
      const subject = byId(state.subjects, assignment.subjectId);
      if (!subject) return false;
      return activeView === "batch"
        ? subject.batch === selected
        : subject.facultyId === selected;
    });
    const violations = lastViolations;
    const clashIds = new Set();
    for (const assignment of filtered) {
      const subject = byId(state.subjects, assignment.subjectId);
      if (!subject) continue;
      const broken = makeCandidateViolations(assignment, subject, state.schedule).length > 0;
      if (broken) clashIds.add(assignment.id);
    }
    const tableHead = $("#timetable-head");
    tableHead.innerHTML = `<tr><th>DAY</th>${PERIODS.map((time, index) =>
      `<th>PERIOD ${index + 1}<br><span>${time}</span></th>`).join("")}</tr>`;

    const tableBody = $("#timetable-body");
    tableBody.innerHTML = DAYS.map((day, dayIndex) => {
      const cells = Array.from({ length: PERIODS.length }, (_, period) => {
        const classes = filtered.filter((assignment) => {
          const subject = byId(state.subjects, assignment.subjectId);
          return assignment.day === dayIndex && assignment.period <= period &&
            assignment.period + (subject ? hoursFor(subject) : 1) > period;
        });
        const hasClash = classes.some((item) => clashIds.has(item.id));
        const cards = classes.map((assignment) => {
          const subject = byId(state.subjects, assignment.subjectId);
          const room = byId(state.rooms, assignment.roomId);
          if (!subject) return "";
          const isStart = assignment.period === period;
          const label = isStart ? subject.name : `${subject.name} · continued`;
          const details = `${isStart ? (room?.name || "Room missing") : "Continued block"} · ${byId(state.faculty, subject.facultyId)?.name || "Faculty missing"}`;
          return `<div class="class-card type-${subject.type === "lab" ? "lab" : "lecture"}${clashIds.has(assignment.id) ? " is-clash" : ""}"
              draggable="true" data-class-id="${escapeHtml(assignment.id)}" data-offset="${period - assignment.period}"
              title="${escapeHtml(`${subject.name} · ${DAYS[dayIndex]} · period ${assignment.period + 1}`)}">
              <span class="class-name">${escapeHtml(label)}</span>
              <span class="class-detail">${escapeHtml(details)}</span>
              ${clashIds.has(assignment.id) ? '<span class="clash-mark">!</span>' : ""}
            </div>`;
        }).join("");
        const slot = `${dayIndex}-${period}`;
        return `<td class="${hasClash ? "has-clash" : ""}" data-day="${dayIndex}" data-period="${period}" data-slot="${slot}">${cards || '<div class="drop-placeholder"></div>'}</td>`;
      }).join("");
      return `<tr><th>${day}</th>${cells}</tr>`;
    }).join("");
    $("#timetable").setAttribute("aria-label", `${activeView === "batch" ? "Batch" : "Faculty"} timetable`);
    if (filtered.length === 0) {
      $("#view-description").textContent = `No classes scheduled for ${activeView === "batch" ? (selected || "this batch") : (byId(state.faculty, selected)?.name || "this faculty member")}. Generate a timetable to get started.`;
    }
    void violations;
  }

  function resourceDescription(type, item) {
    if (type === "subjects") {
      const faculty = byId(state.faculty, item.facultyId);
      const kind = item.type === "lab" ? `${item.duration}-period lab` : `${item.sessions} sessions / week`;
      return `${item.batch} · ${kind} · ${faculty ? faculty.name : "No faculty"}`;
    }
    if (type === "faculty") {
      const assigned = state.subjects.filter((subject) => subject.facultyId === item.id).length;
      return `${item.maxHours}h weekly limit · ${assigned} subject${assigned === 1 ? "" : "s"}`;
    }
    const equipment = (item.equipment || []).length ? item.equipment.join(", ") : "Lecture room";
    return `${item.capacity} seats · ${equipment}`;
  }

  function renderResourceForm() {
    const form = $("#resource-form");
    if (activeResourceTab === "subjects") {
      const batches = [...new Set([...state.subjects.map((item) => item.batch), "CS-A", "CS-B", "CS-C"])].sort();
      form.innerHTML = `
        <input name="name" placeholder="Subject name" aria-label="Subject name" required maxlength="45">
        <select name="batch" aria-label="Batch">${batches.map((batch) => `<option value="${escapeHtml(batch)}">${escapeHtml(batch)}</option>`).join("")}</select>
        <select name="facultyId" aria-label="Faculty" required>${state.faculty.map((faculty) => `<option value="${escapeHtml(faculty.id)}">${escapeHtml(faculty.name)}</option>`).join("")}</select>
        <input name="sessions" type="number" min="1" max="10" value="2" placeholder="Sessions / week" aria-label="Sessions per week" required>
        <select name="type" aria-label="Class type"><option value="lecture">Lecture · 1 period</option><option value="lab">Lab · 2 periods</option></select>
        <button type="submit">Add</button>
        <span class="hint">Labs use a 2-period block and require a computer-equipped room.</span>`;
      if (!state.faculty.length) form.innerHTML = `<span class="hint">Add a faculty member before creating a subject.</span>`;
    } else if (activeResourceTab === "faculty") {
      form.innerHTML = `
        <input class="wide" name="name" placeholder="Faculty name" aria-label="Faculty name" required maxlength="45">
        <input name="maxHours" type="number" min="1" max="40" value="12" placeholder="Weekly limit" aria-label="Maximum weekly hours" required>
        <button type="submit">Add</button>
        <span class="hint">Faculty availability can be managed by blocking periods in the timetable.</span>`;
    } else {
      form.innerHTML = `
        <input name="name" placeholder="Room name" aria-label="Room name" required maxlength="35">
        <input name="capacity" type="number" min="1" max="500" value="30" placeholder="Seats" aria-label="Room capacity" required>
        <input class="wide" name="equipment" placeholder="Equipment, comma separated (e.g. computers)" aria-label="Room equipment">
        <button type="submit">Add</button>`;
    }
  }

  function renderResources() {
    const list = state[activeResourceTab];
    $("#resource-list").innerHTML = list.length
      ? list.map((item, index) => {
        const name = item.name;
        const initial = escapeHtml(name.trim().slice(0, 1).toUpperCase() || "?");
        return `<div class="resource-row">
          <span class="resource-avatar ${activeResourceTab}">${initial}</span>
          <span class="resource-copy"><strong>${escapeHtml(name)}</strong><small>${escapeHtml(resourceDescription(activeResourceTab, item))}</small></span>
          <button type="button" class="delete-resource" data-delete-index="${index}" aria-label="Remove ${escapeHtml(name)}" title="Remove">×</button>
        </div>`;
      }).join("")
      : `<div class="empty-resources">No ${activeResourceTab} added yet.</div>`;
    $("#subject-count").textContent = state.subjects.length;
    $("#faculty-count").textContent = state.faculty.length;
    $("#room-count").textContent = state.rooms.length;
    $("#resource-total").textContent = `${state.subjects.length + state.faculty.length + state.rooms.length} resources`;
    renderResourceForm();
  }

  function renderAudit() {
    lastViolations = auditSchedule();
    const auditList = $("#audit-list");
    const allTasks = getTasks();
    const assigned = new Set(state.schedule.map((item) => item.id));
    const unplaced = lastUnscheduled.length
      ? lastUnscheduled
      : allTasks.filter((task) => !assigned.has(task.id)).map((task) => {
        const subject = byId(state.subjects, task.subjectId);
        return subject ? `${subject.name} (${subject.batch})` : "An unassigned class";
      });
    const entries = [
      ...lastViolations.map((item) => ({ title: item.message, detail: "Hard constraint violation", type: item.type })),
      ...unplaced.map((name) => ({ title: `Not scheduled: ${name}`, detail: "Needs an available timetable slot", type: "unscheduled" }))
    ];
    const count = entries.length;
    $("#audit-badge").textContent = `${count} ${count === 1 ? "issue" : "issues"}`;
    $("#audit-badge").classList.toggle("clear", count === 0);
    $("#audit-badge").classList.toggle("error", count > 0);
    $("#nav-clash-count").textContent = count;
    $("#nav-clash-count").style.display = count ? "" : "none";
    $("#stat-health").textContent = count ? "Needs attention" : "All clear";
    $("#health-indicator").style.background = count ? "#d95360" : "#55b48a";
    $("#stat-clashes").textContent = count ? `${count} issue${count === 1 ? "" : "s"} to resolve` : "No clashes detected";
    auditList.innerHTML = count
      ? entries.map((item) => `<div class="audit-row">
          <span class="audit-symbol">!</span>
          <span><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.detail)}</small></span>
        </div>`).join("")
      : `<div class="audit-clear"><span class="audit-check">✓</span> No clashes. Your timetable is looking good.</div>`;
    updateStats();
  }

  function updateStats() {
    const assigned = state.schedule.filter((assignment) => byId(state.subjects, assignment.subjectId));
    const scheduledHours = assigned.reduce((sum, assignment) => sum + hoursFor(byId(state.subjects, assignment.subjectId)), 0);
    const totalCapacity = state.faculty.reduce((sum, faculty) => sum + Number(faculty.maxHours || 0), 0);
    const utilization = totalCapacity ? Math.min(100, Math.round((scheduledHours / totalCapacity) * 100)) : 0;
    $("#stat-classes").textContent = assigned.length;
    $("#stat-class-detail").textContent = `Across ${new Set(state.subjects.map((subject) => subject.batch)).size} batches`;
    $("#stat-utilization").textContent = utilization;
    $("#utilization-bar").style.width = `${utilization}%`;
    $("#stat-resources").textContent = state.faculty.length + state.rooms.length;
    $("#stat-resource-detail").textContent = `${state.faculty.length} faculty · ${state.rooms.length} rooms`;
  }

  function render() {
    renderResources();
    renderAudit();
    renderTimetable();
    persistState();
  }

  function addResource(event) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    if (activeResourceTab === "subjects") {
      if (!state.faculty.length) {
        showToast("Add a faculty member before creating a subject.");
        return;
      }
      const type = formData.get("type");
      const name = String(formData.get("name") || "").trim();
      if (!name) return;
      const subject = {
        id: createId("sub"),
        name,
        batch: String(formData.get("batch") || "CS-A"),
        facultyId: String(formData.get("facultyId")),
        sessions: Number(formData.get("sessions")),
        duration: type === "lab" ? 2 : 1,
        type,
        minCapacity: 25,
        equipment: type === "lab" ? ["computers"] : []
      };
      state.subjects.push(subject);
      showToast(`${name} added to ${subject.batch}. Generate a timetable to schedule it.`);
    } else if (activeResourceTab === "faculty") {
      const name = String(formData.get("name") || "").trim();
      if (!name) return;
      state.faculty.push({ id: createId("fac"), name, maxHours: Number(formData.get("maxHours")), unavailable: [] });
      showToast(`${name} added to your faculty.`);
    } else {
      const name = String(formData.get("name") || "").trim();
      if (!name) return;
      const equipment = String(formData.get("equipment") || "")
        .split(",").map((item) => item.trim().toLowerCase()).filter(Boolean);
      state.rooms.push({
        id: createId("room"),
        name,
        capacity: Number(formData.get("capacity")),
        equipment: [...new Set(equipment)]
      });
      showToast(`${name} added to your rooms.`);
    }
    state.schedule = state.schedule.filter((assignment) => byId(state.subjects, assignment.subjectId));
    lastUnscheduled = [];
    render();
  }

  function removeResource(index) {
    const removed = state[activeResourceTab][index];
    if (!removed) return;
    if (activeResourceTab === "faculty" && state.subjects.some((subject) => subject.facultyId === removed.id)) {
      showToast("Reassign this faculty member's subjects before removing them.");
      return;
    }
    if (activeResourceTab === "subjects") {
      state.schedule = state.schedule.filter((assignment) => assignment.subjectId !== removed.id);
    } else if (activeResourceTab === "rooms") {
      state.schedule = state.schedule.filter((assignment) => assignment.roomId !== removed.id);
    }
    state[activeResourceTab].splice(index, 1);
    lastUnscheduled = [];
    render();
    showToast(`${removed.name} removed.`);
  }

  function moveClass(classId, day, period) {
    const assignment = getAssignment(classId);
    const subject = assignment && byId(state.subjects, assignment.subjectId);
    if (!assignment || !subject) return;
    const duration = hoursFor(subject);
    if (day < 0 || day >= DAYS.length || period < 0 || period + duration > PERIODS.length) {
      showToast("That class block will not fit in the selected day.");
      return;
    }
    assignment.day = day;
    assignment.period = period;
    lastUnscheduled = [];
    render();
    const conflicts = makeCandidateViolations(assignment, subject, state.schedule);
    if (conflicts.length) {
      showToast(`Clash: ${conflicts[0].message}`);
    } else {
      showToast(`${subject.name} moved to ${DAYS[day]}, period ${period + 1}.`);
    }
  }

  function bindEvents() {
    $$(".nav-item").forEach((button) => button.addEventListener("click", () => {
      const section = document.getElementById(button.dataset.scroll);
      section?.scrollIntoView({ behavior: "smooth", block: "start" });
      $$(".nav-item").forEach((item) => item.classList.toggle("active", item === button));
    }));

    $$(".segment").forEach((button) => button.addEventListener("click", () => {
      activeView = button.dataset.view;
      $$(".segment").forEach((item) => item.classList.toggle("active", item === button));
      renderTimetable();
    }));

    $("#schedule-filter").addEventListener("change", renderTimetable);

    $$(".resource-tab").forEach((button) => button.addEventListener("click", () => {
      activeResourceTab = button.dataset.resourceTab;
      $$(".resource-tab").forEach((item) => {
        const active = item === button;
        item.classList.toggle("active", active);
        item.setAttribute("aria-selected", String(active));
      });
      renderResources();
    }));

    $("#resource-form").addEventListener("submit", addResource);
    $("#resource-list").addEventListener("click", (event) => {
      const button = event.target.closest("[data-delete-index]");
      if (button) removeResource(Number(button.dataset.deleteIndex));
    });

    $("#generate-button").addEventListener("click", () => {
      const button = $("#generate-button");
      button.disabled = true;
      button.innerHTML = '<span class="sparkle">◌</span> Finding the best fit…';
      window.setTimeout(() => {
        const result = solveTimetable();
        button.disabled = false;
        button.innerHTML = '<span class="sparkle">✳</span> Generate timetable <span class="button-arrow">↗</span>';
        if (!result.solved) {
          showToast(result.reason);
          lastUnscheduled = getTasks()
            .filter((task) => !state.schedule.some((item) => item.id === task.id))
            .map((task) => {
              const subject = byId(state.subjects, task.subjectId);
              return subject ? `${subject.name} (${subject.batch})` : "An unassigned class";
            });
          if (!lastUnscheduled.length) lastUnscheduled = state.subjects.map((subject) => `${subject.name} (${subject.batch})`);
          render();
          return;
        }
        state.schedule = result.schedule;
        lastUnscheduled = [];
        render();
        showToast(`Conflict-free timetable generated in ${result.visited} CSP steps.`);
      }, 30);
    });

    $("#print-button").addEventListener("click", () => window.print());
    $("#reset-demo").addEventListener("click", () => {
      state = structuredClone(demoData);
      lastUnscheduled = [];
      render();
      showToast("Demo data restored.");
    });

    $("#timetable-body").addEventListener("dragstart", (event) => {
      const card = event.target.closest(".class-card");
      if (!card) return;
      draggedClassId = card.dataset.classId;
      draggedOffset = Number(card.dataset.offset || 0);
      card.style.opacity = ".45";
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", draggedClassId);
    });
    $("#timetable-body").addEventListener("dragend", (event) => {
      const card = event.target.closest(".class-card");
      if (card) card.style.opacity = "";
      $$(".timetable td.drag-over").forEach((cell) => cell.classList.remove("drag-over"));
      draggedClassId = null;
    });
    $("#timetable-body").addEventListener("dragover", (event) => {
      const cell = event.target.closest("td[data-slot]");
      if (!cell) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = "move";
      $$(".timetable td.drag-over").forEach((item) => item.classList.remove("drag-over"));
      cell.classList.add("drag-over");
    });
    $("#timetable-body").addEventListener("dragleave", (event) => {
      const cell = event.target.closest("td[data-slot]");
      if (cell && !cell.contains(event.relatedTarget)) cell.classList.remove("drag-over");
    });
    $("#timetable-body").addEventListener("drop", (event) => {
      const cell = event.target.closest("td[data-slot]");
      if (!cell) return;
      event.preventDefault();
      cell.classList.remove("drag-over");
      const classId = draggedClassId || event.dataTransfer.getData("text/plain");
      moveClass(classId, Number(cell.dataset.day), Number(cell.dataset.period) - draggedOffset);
    });
    $("#timetable-body").addEventListener("click", (event) => {
      const card = event.target.closest(".class-card.is-clash");
      if (card) $("#audit-section").scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }

  bindEvents();
  render();
})();